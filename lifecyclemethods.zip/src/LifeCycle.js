import React, { Component } from 'react';

class LifeCycle extends Component {
  constructor(props) {
    super(props);
    this.state = {
      count: 0
    };
    console.log('Constructor called');
  }

  componentDidMount() {
    console.log('ComponentDidMount called');
  }

  componentDidUpdate(prevProps, prevState) {
    console.log('ComponentDidUpdate called');
    if (prevState.count !== this.state.count) {
      console.log('Count state has changed');
    }
  }

  componentWillUnmount() {
    console.log('ComponentWillUnmount called');
  }

  shouldComponentUpdate(nextProps, nextState) {
    console.log('ShouldComponentUpdate called');
    return nextState.count % 2 === 0;
  }

  handleClick = () => {
    this.setState(prevState => ({
      count: prevState.count + 1
    }));
  }

  render() {
    console.log('Render called');
    return (
      <div className="lifecycle">
        <h2>Count: {this.state.count}</h2>
        <button onClick={this.handleClick}>Increment Count</button>
      </div>
    );
  }
}

export default LifeCycle;
