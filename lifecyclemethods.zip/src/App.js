import React, { Component } from 'react';
import './LifeCycle.css';
import LifeCycle from './LifeCycle';

class App extends Component {
  render() {
    return (
      <div className="app">
        <h1>React Lifecycle Methods</h1>
        <LifeCycle />
      </div>
    );
  }
}

export default App;


